<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/Exam.php');
	$exm = new Exam();
?>
<style>
.adminpanel{width:500px;color:#999; margin:20px auto 0; 
padding:10px; border:1px solid #ddd;}
</style>
<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$sub = $_POST['sub'];
		echo "<script>window.location='numberofqsrandomly.php?sub=".$sub."'</script>";
	}
?>
<div class="main">
<h1>Admin Panel - Choose Subject</h1>

	<div class="adminpanel">

		 <form action="" method="post" enctype="multipart/form-data">
        <table class="form">
           <tr>
              
            <tr>
                <td>
                    <select id="select" name="sub">
                    <option>Select Subject</option>
                      <option value="1">C</option>
                      <option value="2">C++</option>
                      <option value="3">C#</option>
                      <option value="4">Java</option>
                      <option value="4">PHP</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="submit" Value="Go" />
                </td>
            </tr>
        </table>
        </form>
	</div>
	
</div>
<?php include 'inc/footer.php'; ?>