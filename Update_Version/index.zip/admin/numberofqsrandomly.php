<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/Exam.php');
	$exm = new Exam();
?>
<style>
.adminpanel{width:800px;color:#999; margin:20px auto 0; 
padding:10px; border:1px solid #ddd;}
</style>
<?php 
$number=0;
  if(isset($_GET['sub'])){
    $sub = $_GET['sub'];
  }
  $totalqspersub = $exm->subwisetotalcurrentqs($sub);
  if($totalqspersub){
  $number = mysqli_num_rows($totalqspersub);
}

?>
<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
    $random = $_POST['random'];
		$totalqs = $_POST['totalqs'];
    if($totalqs>=$random){
		echo "<script>window.location='quesadd.php?sub=".$sub."&randqs=".$random."'</script>";
    }else{
        $msg = "Must be less than total questions";
    }
	}
?>
<div class="main">
<h1>Admin Panel - Select number of Questions want to show randomly: </h1>

	<div class="adminpanel">
     <?php
          if(isset($msg)){
            echo "<span style='color:crimson;'>$msg</span>";
          }
     ?>
		 <form action="" method="post" enctype="multipart/form-data">
        <table class="form">
       
           <tr>
            <td>Current total set Questions for this subject</td>
            <td>:</td>
            <td><input type="text" value="<?php echo $number; ?>" name="totalqs" readonly /></td>
        </tr>
        <tr>
            <td>Total Random Questions to show</td>
            <td>:</td>
            <td><input type="text" name="random" placeholder="Must be less than total questions" required /></td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="submit" Value="Go" />
            </td>
        </tr>
        </table>
        </form>
	</div>
	
</div>
<?php include 'inc/footer.php'; ?>