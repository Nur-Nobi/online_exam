<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/Session.php');
	//Session::init();
	include_once ($filepath.'/../lib/Database.php');
	include_once ($filepath.'/../helpers/Format.php');

	class Process{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function processData($data,$arr){
			
			$selectAns = $this->fm->validation($data['ans']);
			$number = $this->fm->validation($data['number']);
			$selectAns = mysqli_real_escape_string($this->db->link, $selectAns);
			$number = mysqli_real_escape_string($this->db->link, $number);
			for($i=0;$i<count($arr);$i++){
				if($arr[$i]==$number){
                   $next = $arr[$i+1];
				}
				
			}
			if(!isset($_SESSION['score'])){
				$_SESSION['score'] = '0';
			}

			$gsid = $this->getSubId($number);
			
			$totalc = count($arr);
			$total = $arr[$totalc-1];
			$right = $this->rightAns($number);
			if($right == $selectAns){
				$_SESSION['score']++;
			}
			if($number == $total){
				header("Location:final.php?sub_id=".$gsid);
				exit();
			}else{
				header("Location:test.php?q=".$next."&other=".implode(".",$arr));
				//header("Location:test.php?q=".$next."&other=".$gsid);
			}
		}
		
		private function getTotal(){
			$query = "SELECT * FROM tbl_ques";
			$getresult = $this->db->select($query);
			$total = $getresult->num_rows;
			return $total;
		}
		private function getSubId($id){
			$query = "SELECT * FROM tbl_ques where quesNo='$id' limit 1";
			$getresult = $this->db->select($query);
			$value = $getresult->fetch_assoc();
			$data = $value['sub_id'];
			return $data;
		}	
		private function rightAns($number){
			$query = "SELECT * FROM tbl_ans Where quesNo='$number' AND rightAns='1'";
			$getdata = $this->db->select($query)->fetch_assoc();
			$result = $getdata['id'];
			return $result;
		}
	}

?>